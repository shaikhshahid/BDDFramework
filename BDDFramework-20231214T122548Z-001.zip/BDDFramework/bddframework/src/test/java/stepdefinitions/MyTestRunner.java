/*
 * This is TestRunner which helps us to execute the Scenario, hooks and add plugin for TestReports
 */
package stepdefinitions;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features = "Features", glue = { "stepdefinitions" ,"hooks"}, plugin = { "pretty",
		"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:" }, monochrome = true, publish=true)

public class MyTestRunner {

}
