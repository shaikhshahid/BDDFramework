/*
 * These are the step definitions which we have drivd from our feature file
 */

package stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import io.cucumber.java.en.*;
import pageObjects.LoginPage;
import utils.ConfigReader;
import utils.SetBrowser;
import utils.WaitHelper;


public class LoginPageSteps{
	
	public WebDriver driver;
	public LoginPage lobj;
	public ConfigReader cr = new ConfigReader("config.properties");
	public String actualTitle;

	@Given("user is on login page")
	public void user_is_on_login_page()  {
		String browserName = cr.getProperty("browser");
		driver= SetBrowser.browser(browserName);
		lobj=new LoginPage(driver);
		String url = cr.getProperty("url");
		driver.get(url);
	}

	@When("user gets the title of the page")
	public void user_gets_the_title_of_the_page() {
		actualTitle=driver.getTitle();
	}

	@Then("page title should be {string}")
	public void page_title_should_be(String expectedTitle) {
		
		Assert.assertEquals(expectedTitle, actualTitle);
	 
	}

	@When("user enters username {string}")
	public void user_enters_username(String username) {

	   lobj.userLogin(username);
	}

	@And("user enters password {string}")
	public void user_enters_password(String password) {

		lobj.enterPass(password);
	}

	@And("user clicks on Submit button")
	public void user_clicks_on_submit_button() throws InterruptedException {
	
		lobj.submitButton();
		WaitHelper waithelper = new WaitHelper(driver);
		waithelper.waitForPageLoad(10);
		
		
	}
	
	@Then("close the browser")
	public void close_the_browser()
	{
		driver.close();
	}

	
}
