package hooks;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import io.cucumber.java.*;
import utils.SetBrowser;

public class MercuryTourHooks extends SetBrowser {

	// We can specify Tags / order - Before any Scenario this will be executed
	@Before("@Smoke")
	public void nameOfMethod() {

	}

	// Teardown - After any Scenario this will be executed
	@After()
	public void takeScreenhsot(Scenario scenario) {

		if (scenario.isFailed()) {
			TakesScreenshot screenshot = (TakesScreenshot) driver;
			byte[] src = screenshot.getScreenshotAs(OutputType.BYTES);
			scenario.attach(src, "image/png","FailedScreenshot");
		}

	}

}
