/*
 * Used Page Object Model and PageFactory to locate and find the Elements on the page
 */

package pageObjects;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;

public class LoginPage {

	public WebDriver ldriver;

	public LoginPage(WebDriver rdriver) {
		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	@FindBy(name = "userName")
	@CacheLookup
	WebElement uname;

	@FindBy(name = "password")
	@CacheLookup
	WebElement password;

	@FindBy(name = "submit")
	@CacheLookup
	WebElement submitBtn;

	public void userLogin(String username) {

		uname.sendKeys(username);
	}

	public void enterPass(String pass) {

		password.sendKeys(pass);
	}

	public void submitButton() {
		submitBtn.click();

	}

}
