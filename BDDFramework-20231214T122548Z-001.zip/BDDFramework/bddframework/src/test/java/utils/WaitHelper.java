package utils;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WaitHelper {

	public static WebDriver driver;
	
	public WaitHelper(WebDriver driver)
	{
		WaitHelper.driver=driver;
	}
	
	
	public void WaitForShort()
	{
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	public void WaitForElement(WebElement element, long time)
	{
		WebDriverWait wait= new WebDriverWait(driver, time);
		wait.until(ExpectedConditions.visibilityOf(element));
	}
	
	public void waitForPageLoad(int time)
	{
		WebDriverWait wait= new WebDriverWait(driver, time);
		wait.until(WebDriver -> ((JavascriptExecutor) driver).executeScript("return document.readyState").toString().equals("complete"));
	}
}
