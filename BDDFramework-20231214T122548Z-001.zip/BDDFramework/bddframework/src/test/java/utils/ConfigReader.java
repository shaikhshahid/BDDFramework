package utils;
import java.io.*;
import java.util.Properties;

public class ConfigReader 
{
	static Properties props = new Properties();
	String strFileName;
	String strValue;

	public ConfigReader(String strFileName)
	{
		this.strFileName = strFileName;
	}

	public String getProperty(String strKey)
	{
		try {
			File file = new File(strFileName);
			if (file.exists())
			{
				FileInputStream finput = new FileInputStream(file);
				props.load(finput);
				strValue = props.getProperty(strKey);
				finput.close();
			}
			else
			{
				System.out.println("File not found, please check name properly");
			}
		} 

		catch (Exception exe)
		{
			System.out.println(exe);
		}

		return strValue;
	}

}